# Pizzaria
Minetest Pizzaria mod that adds advanced pizza baking as a late-game food source

Due to MTG's lack of animals and certain plants I've added the rather silly "Mese Mutation Crystal" to turn other items into the ones needed.

### - Mutations:

- Mutating an apple gives a tomato
- Mutating an apple with two pine leaves gives pineapple
- Mutating a player's bones gives 9 Meat
- Mutating blueberries gives olives
And probably the wackiest of all:
- Mutating Gold fives cheese

### - Curing:

Pepperoni has to be cured, craft your pepperoni then hang it from your ceiling until it's fully cured.

### - Pizza prep

1. Craft a bucket of water with flour to make 2x Pizza dough
2. Place the pizza dough then punch it with a rolling pin until it breaks and is rolled out into a pizza base
3. Place on your cheese, and tomato sauce
4. Add whatever 1-2 toppings your heart desires
5. Place your pizza into your pizza oven and stoke the fire with tree logs
6. Ignite your fire with a torch by punching it
7. Wait until your pizza is done, be careful not to burn it!
8. Finally remove your pizza and place it down in a pizza box or on your table
9. Cut it up and enjoy!
